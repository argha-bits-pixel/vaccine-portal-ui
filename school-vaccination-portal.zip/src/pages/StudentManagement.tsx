import {
  ActionIcon,
  Button,
  Card,
  // Checkbox,
  Container,
  FileInput,
  Group,
  Loader,
  Modal,
  NumberInput,
  Pagination,
  Select,
  Table,
  TextInput,
} from "@mantine/core";
import { useForm } from "@mantine/form";
import { IconEdit, IconSearch, IconVaccine } from "@tabler/icons-react";
import React, { useEffect, useState } from "react";
import Header from "../components/header";
import useStudent from "../utils/hooks/useStudent";
import { Student, VaccineStudentFormSchema } from "../utils/types";
import { classes, genders } from "../utils/constants";

const limit = 5;

const StudentManagement: React.FC = () => {
  const {
    addStudent,
    fetchStudents,
    vaccinateStudent,
    loading,
    students,
    updateStudent,
    total,
    bulkUpload,
    saving,
  } = useStudent();
  const [searchQueryObj, setSearchQueryObj] = useState({
    name: "",
    class: "",
    gender: "",
    roll_no: "",
    phone_no: "",
    vaccine_name: "",
  });
  const [modalOpen, setModalOpen] = useState(false);
  const [vaccinateModalOpen, setVaccinateModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [page, setPage] = useState(1);

  const form = useForm<Student>({
    initialValues: {
      name: "",
      class: "",
      gender: "",
      roll_no: "",
      phone_no: "",
    },
    validate: {
      name: (value) => {
        return value.length < 2 ? "name must have at least 2 letters" : null;
      },
      class: (value) => (value.length < 1 ? "Class cannot be empty" : null),
      gender: (value) => (value.length < 1 ? "Gender cannot be empty" : null),
      roll_no: (value) => (value.length < 1 ? "Roll No cannot be empty" : null),
      phone_no: (value) =>
        value.length < 1 ? "Phone No cannot be empty" : null,
    },
  });

  const vaccinateForm = useForm<VaccineStudentFormSchema>({
    initialValues: {
      student_id: null,
      drive_id: null,
    },
    validate: {
      student_id: (value) =>
        value === null ? "Student id cannot be empty" : null,
      drive_id: (value) => (value === null ? "Drive id cannot be empty" : null),
    },
  });

  useEffect(() => {
    fetchStudents({
      limit,
      page,
      searchQueryObj,
    });
  }, [fetchStudents, page, searchQueryObj]);

  const handleSubmitAddEditStudent = React.useCallback(
    async (values: Student) => {
      if (editingStudent) {
        await updateStudent(values);
      } else {
        await addStudent(values);
      }
      setModalOpen(false);
      setEditingStudent(null);
      form.reset();
    },
    [addStudent, editingStudent, form, updateStudent]
  );

  const handleBulkUploadStudent = React.useCallback(
    async (file: File) => {
      await bulkUpload(file);
    },
    [bulkUpload]
  );

  const handleVaccinate = React.useCallback(
    (student: Student) => {
      setEditingStudent(student);
      vaccinateForm.setValues({
        student_id: student.id || null,
        drive_id: null,
      });
      setVaccinateModalOpen(true);
    },
    [vaccinateForm]
  );

  const handleSubmitStudentVaccination = React.useCallback(
    async (values: VaccineStudentFormSchema) => {
      await vaccinateStudent(values);
      setVaccinateModalOpen(false);
      setEditingStudent(null);
      vaccinateForm.reset();
    },
    [vaccinateForm, vaccinateStudent]
  );

  const handleEdit = React.useCallback(
    (student: Student) => {
      setEditingStudent(student);
      form.setValues(student);
      setModalOpen(true);
    },
    [form]
  );

  const handleChangeQuery = React.useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      setSearchQueryObj((prev) => ({
        ...prev,
        [e.target.name]: e.target.value,
      }));
    },
    []
  );
  return (
    <div>
      <Header />
      <Container mt="md">
        <Group mb="md">
          <Group>
            <Button onClick={() => setModalOpen(true)}>Add Student</Button>
            <FileInput
              placeholder="Bulk Import"
              accept=".xlsx"
              onChange={(file) => {
                if (file) handleBulkUploadStudent(file);
              }}
              color="blue"
            />
          </Group>
        </Group>
        <Card shadow="sm" padding="xs">
          <Table>
            <Table.Thead>
              <Table.Tr>
                <Table.Th>ID</Table.Th>
                <Table.Th>
                  Name
                  <TextInput
                    placeholder="Search by Name"
                    leftSection={<IconSearch />}
                    value={searchQueryObj.name}
                    name="name"
                    onChange={handleChangeQuery}
                  />
                </Table.Th>
                <Table.Th>
                  Class
                  <TextInput
                    placeholder="Search by Class"
                    leftSection={<IconSearch />}
                    value={searchQueryObj.class}
                    name="class"
                    onChange={handleChangeQuery}
                  />
                </Table.Th>
                <Table.Th>Gender</Table.Th>
                <Table.Th>
                  Roll No
                  <TextInput
                    placeholder="Search by roll number"
                    name="roll_no"
                    leftSection={<IconSearch />}
                    value={searchQueryObj.roll_no}
                    onChange={handleChangeQuery}
                  />
                </Table.Th>
                <Table.Th>Phone No</Table.Th>
                <Table.Th>Vaccination</Table.Th>
                <Table.Th>Vaccine</Table.Th>
                <Table.Th style={{ width: "80px" }}>Actions</Table.Th>
              </Table.Tr>
            </Table.Thead>
            <Table.Tbody>
              {loading ? (
                <Loader />
              ) : (
                students.map((student) => (
                  <tr key={student.id}>
                    <Table.Td>{student.id}</Table.Td>
                    <Table.Td>{student.name}</Table.Td>
                    <Table.Td>{student.class}</Table.Td>
                    <Table.Td>{student.gender}</Table.Td>
                    <Table.Td>{student.roll_no}</Table.Td>
                    <Table.Td>{student.phone_no}</Table.Td>
                    <Table.Td>{student.vaccination ? "Yes" : "No"}</Table.Td>
                    <Table.Td>{student.vaccine_name}</Table.Td>
                    <Table.Td>
                      <Group dir="col">
                        <ActionIcon
                          size="sm"
                          onClick={() => handleEdit(student)}
                        >
                          <IconEdit />
                        </ActionIcon>
                        <ActionIcon
                          size="sm"
                          onClick={() => handleVaccinate(student)}
                          disabled={student.vaccination}
                        >
                          <IconVaccine />
                        </ActionIcon>
                      </Group>
                    </Table.Td>
                  </tr>
                ))
              )}
            </Table.Tbody>
          </Table>

          <Pagination
            total={Math.ceil(total / limit)}
            value={page}
            onChange={setPage}
            mt="md"
          />
        </Card>

        <Modal
          opened={modalOpen}
          onClose={() => {
            setModalOpen(false);
            setEditingStudent(null);
            form.reset();
          }}
          title={editingStudent ? "Edit Student" : "Add Student"}
        >
          <form onSubmit={form.onSubmit(handleSubmitAddEditStudent)}>
            <TextInput
              label="Name"
              placeholder="Enter student name"
              {...form.getInputProps("name")}
              required
            />
            <Select
              label="Class"
              placeholder="Select class"
              data={classes}
              {...form.getInputProps("class")}
              required
            />
            <Select
              label="Gender"
              placeholder="Select gender"
              data={genders}
              disabled={editingStudent ? true : false}
              {...form.getInputProps("gender")}
              required
            />
            <TextInput
              label="Roll No"
              placeholder="Enter roll number"
              disabled={editingStudent ? true : false}
              {...form.getInputProps("roll_no")}
              required
            />
            <TextInput
              label="Phone No"
              placeholder="Enter phone number"
              {...form.getInputProps("phone_no")}
              required
            />

            <Group justify="flex-start" mt="md">
              <Button type="submit" disabled={saving} loading={saving}>
                {editingStudent ? "Update" : "Add"}
              </Button>
            </Group>
          </form>
        </Modal>

        <Modal
          opened={vaccinateModalOpen}
          onClose={() => {
            setVaccinateModalOpen(false);
            setEditingStudent(null);
            vaccinateForm.reset();
          }}
          title={"Vaccinate Student"}
        >
          <form
            onSubmit={vaccinateForm.onSubmit(handleSubmitStudentVaccination)}
          >
            <NumberInput
              label="Drive ID"
              placeholder="Enter drive ID"
              {...vaccinateForm.getInputProps("drive_id")}
              required
            />

            <Group justify="flex-end" mt="md">
              <Button type="submit">Vaccinate</Button>
            </Group>
          </form>
        </Modal>
      </Container>
    </div>
  );
};

export default StudentManagement;
