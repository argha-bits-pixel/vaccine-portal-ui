import {
  Card,
  Container,
  Loader,
  Pagination,
  Table,
  TextInput,
} from "@mantine/core";
import { IconSearch } from "@tabler/icons-react";
import axios from "axios";
import React, { useEffect, useState } from "react";
import Header from "../components/header";
import { student_service_url } from "../utils/urls";

interface Student {
  id: number;
  name: string;
  class: string;
  gender: string;
  roll_no: string;
  phone_no: string;
  vaccination: boolean;
  vaccine_name: string;
  vaccine_date: string;
}

const Reports: React.FC = () => {
  const [students, setStudents] = useState<Student[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [page, setPage] = useState(1);
  const limit = 5;

  const fetchStudents = React.useCallback(async () => {
    setLoading(true);
    try {
      const offset = (page - 1) * limit;
      const response = await axios.get(
        `${student_service_url}/vaccine-records/students?limit=${limit}&offset=${offset}&roll_no=${searchQuery}&vaccine_name=covishield`
      );
      setStudents(response.data.data);
      setTotal(response.data.total);
    } catch (error) {
      console.error("Error fetching students:", error);
    } finally {
      setLoading(false);
    }
  }, [page, searchQuery]);

  useEffect(() => {
    fetchStudents();
  }, [fetchStudents]);

  return (
    <div>
      <Header />
      <Container mt="md">
        <Card shadow="sm" padding="xs">
          <Table>
            <Table.Thead>
              <Table.Tr>
                <Table.Th>ID</Table.Th>
                <Table.Th>Name</Table.Th>
                <Table.Th>Class</Table.Th>
                <Table.Th>Gender</Table.Th>
                <Table.Th>
                  Roll No
                  <TextInput
                    placeholder="Search by roll number"
                    leftSection={<IconSearch />}
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </Table.Th>
                <Table.Th>Phone No</Table.Th>
                <Table.Th>Vaccination</Table.Th>
              </Table.Tr>
            </Table.Thead>
            <Table.Tbody>
              {loading ? (
                <Loader />
              ) : (
                <>
                  {students.map((student) => (
                    <Table.Tr key={student.id}>
                      <Table.Td>{student.id}</Table.Td>
                      <Table.Td>{student.name}</Table.Td>
                      <Table.Td>{student.class}</Table.Td>
                      <Table.Td>{student.gender}</Table.Td>
                      <Table.Td>{student.roll_no}</Table.Td>
                      <Table.Td>{student.phone_no}</Table.Td>
                      <Table.Td>{student.vaccination ? "Yes" : "No"}</Table.Td>
                    </Table.Tr>
                  ))}
                </>
              )}
            </Table.Tbody>
          </Table>

          <Pagination
            total={Math.ceil(total / limit)}
            value={page}
            onChange={setPage}
            mt="md"
          />
        </Card>
      </Container>
    </div>
  );
};

export default Reports;
