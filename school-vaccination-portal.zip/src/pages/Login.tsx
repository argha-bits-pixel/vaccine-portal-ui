import React from "react";
import {
  TextInput,
  PasswordInput,
  Button,
  Container,
  Paper,
  Title,
  Stack,
} from "@mantine/core";

const Login: React.FC = () => {
  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    // Handle login logic here
  };

  return (
    <Container size={"lg"} my={40}>
      <Title
        style={{
          fontFamily: "Greycliff CF, sans-serif",
          fontWeight: 900,
          color: "var(--mantine-color-blue-6)",
        }}
      >
        Login
      </Title>
      <Paper shadow="md" p={30} mt={30} radius="md">
        <form onSubmit={handleSubmit}>
          <Stack gap="md" style={{ width: "300px" }}>
            <TextInput
              label="Username"
              placeholder="Enter your username"
              required
            />
            <PasswordInput
              label="Password"
              placeholder="Enter your password"
              required
            />
            <Button type="submit" fullWidth>
              Login
            </Button>
          </Stack>
        </form>
      </Paper>
    </Container>
  );
};

export default Login;
