import { ActionIcon, Button, Group, Text } from "@mantine/core";
import {
  IconHome,
  IconReport,
  IconUser,
  IconVaccineBottle,
} from "@tabler/icons-react";
import { Link, useLocation } from "react-router";

const Header: React.FC = () => {
  const location = useLocation();
  return (
    <header style={{ backgroundColor: "#f5f5f5", height: "64px" }}>
      <Group h="100%" px="md">
        <Group>
          <ActionIcon
            component={Link}
            to="/dashboard"
            variant={location.pathname === "/dashboard" ? "filled" : "default"}
            aria-label="Settings"
          >
            {/* <Button
            
          /> */}
            <IconHome />
          </ActionIcon>
        </Group>
        <Text c="blue" fw={500}>
          School Vaccination Portal
        </Text>
        <Group>
          <Button
            component={Link}
            to="/students"
            leftSection={<IconUser />}
            variant={location.pathname === "/students" ? "filled" : "default"}
          >
            Student Management
          </Button>
          <Button
            component={Link}
            to="/vaccination-drive"
            leftSection={<IconVaccineBottle />}
            variant={
              location.pathname === "/vaccination-drive" ? "filled" : "default"
            }
          >
            Drive Management
          </Button>
          <Button
            component={Link}
            to="/reports"
            leftSection={<IconReport />}
            variant={location.pathname === "/reports" ? "filled" : "default"}
          >
            Reports
          </Button>
        </Group>
      </Group>
    </header>
  );
};
export default Header;
