import axios from "axios";
import React, { useState } from "react";
import { Student, VaccineStudentFormSchema } from "../types";
import { student_service_url } from "../urls";

function cleanObject(
  obj: Record<string, string | number | boolean | null | undefined>
) {
  for (const propName in obj) {
    if (
      obj[propName] === null ||
      obj[propName] === undefined ||
      obj[propName] === ""
    ) {
      delete obj[propName];
    }
  }
  return obj as Record<string, string | number | boolean>;
}

function getQueryString(
  queryObj: Record<string, string | number | boolean | null | undefined>
) {
  const cleanedQuery = cleanObject(queryObj);
  const queryString = Object.keys(cleanedQuery)
    .map((key) => `${key}=${cleanedQuery[key]}`)
    .join("&");
  return queryString;
}

interface UseStudentResult {
  addStudent: (value: Student) => void;
  updateStudent: (value: Student) => void;
  vaccinateStudent: (info: VaccineStudentFormSchema) => Promise<void>;
  saving: boolean;
  students: Student[];
  total: number;
  loading: boolean;
  fetchStudents: ({
    limit,
    page,
    searchQueryObj,
  }: {
    page: number;
    limit: number;
    searchQueryObj: Record<
      string,
      string | number | boolean | null | undefined
    >;
  }) => Promise<void>;
  bulkUpload: (file: File) => Promise<void>;
}

const useStudent = (): UseStudentResult => {
  const [students, setStudents] = useState<Student[]>([]);
  const [saving, setSaving] = useState<boolean>(false);
  const [loading, setLoading] = useState(false);
  const [total, setTotal] = useState(0);

  const addStudent = React.useCallback(async (student: Student) => {
    setSaving(true);
    try {
      const response = await axios.post(
        `${student_service_url}/students`,
        student,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      console.log("Student added successfully:", response.data);
    } catch (error) {
      console.error("Error adding student:", error);
    } finally {
      setSaving(false);
    }
  }, []);

  const updateStudent = React.useCallback(async (student: Student) => {
    setSaving(true);
    try {
      const response = await axios.patch(
        `${student_service_url}/students`,
        student,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      console.log("Student updated successfully:", response.data);
    } catch (error) {
      console.error("Error updating student:", error);
    } finally {
      setSaving(false);
    }
  }, []);

  const vaccinateStudent = React.useCallback(
    async (info: VaccineStudentFormSchema) => {
      setSaving(true);
      try {
        const response = await axios.post(
          `${student_service_url}/vaccine-records`,
          info,
          {
            headers: {
              "Content-Type": "application/json",
            },
          }
        );
        console.log("Student updated successfully:", response.data);
      } catch (error) {
        console.error("Error updating student:", error);
      } finally {
        setSaving(false);
      }
    },
    []
  );

  const bulkUpload = React.useCallback(async (file: File) => {
    setSaving(true);
    const formData = new FormData();
    const headers = {
      "Content-Type": "multipart/form-data",
      Accept: "application/json",
    };
    formData.append("file", file);

    formData.append("dataFile", file);
    try {
      const response = await axios.put(
        `${student_service_url}/bulk-upload/students`,
        formData,
        {
          headers,
        }
      );
      console.log("Student updated successfully:", response.data);
    } catch (error) {
      console.error("Error updating student:", error);
    } finally {
      setSaving(false);
    }
  }, []);

  const fetchStudents = React.useCallback(
    async ({
      limit,
      page,
      searchQueryObj,
    }: {
      page: number;
      limit: number;
      searchQueryObj: Record<
        string,
        string | number | boolean | null | undefined
      >;
    }) => {
      setLoading(true);
      const queryString = getQueryString(searchQueryObj);
      try {
        const offset = (page - 1) * limit;
        const response = await axios.get(
          `${student_service_url}/vaccine-records/students?limit=${limit}&offset=${offset}&${queryString}`
        );
        setStudents(response.data.data ?? []);
        setTotal(response.data.total ?? 0);
      } catch (error) {
        console.error("Error fetching students:", error);
      } finally {
        setLoading(false);
      }
    },
    []
  );

  return {
    addStudent,
    updateStudent,
    saving,
    students,
    total,
    loading,
    fetchStudents,
    bulkUpload,
    vaccinateStudent,
  };
};

export default useStudent;
