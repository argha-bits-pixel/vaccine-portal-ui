import { useState, useEffect } from "react";
import axios from "axios";
import { VaccineDriveInfo } from "../types";
import React from "react";
import { vaccine_service_url } from "../urls";

interface UseDashboardDataResult {
  data: VaccineDriveInfo[];
  loading: boolean;
  error: string | null;
  addDrive: (drive: VaccineDriveInfo) => Promise<void>;
  updateDrive: (drive: VaccineDriveInfo) => Promise<void>;
  saving: boolean;
}

const useVaccinationDrive = (): UseDashboardDataResult => {
  const [data, setData] = useState<VaccineDriveInfo[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState<boolean>(false);

  const addDrive = React.useCallback(async (drive: VaccineDriveInfo) => {
    setSaving(true);
    try {
      const response = await axios.post(
        `${vaccine_service_url}/vaccine/drives`,
        drive,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      console.log("Student added successfully:", response.data);
    } catch (error) {
      console.error("Error adding student:", error);
    } finally {
      setSaving(false);
    }
  }, []);

  const updateDrive = React.useCallback(async (drive: VaccineDriveInfo) => {
    setSaving(true);
    console.log("drive:====>>>", drive);
    try {
      // const response = await axios.patch(
      //   `${vaccine_service_url}/vaccine/update_drive`,
      //   drive,
      //   {
      //     headers: {
      //       "Content-Type": "application/json",
      //     },
      //   }
      // );
      const resp = await fetch(`${vaccine_service_url}/vaccine/update_drive`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        // body: JSON.stringify(drive),
      });
      console.log("Student updated successfully:", resp);
    } catch (error) {
      console.error("Error updating student:", error);
    } finally {
      setSaving(false);
    }
  }, []);

  const fetchData = React.useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const response = await axios.get("http://localhost:8080/vaccine/drives");
      console.log("data:", response.data);
      setData(response.data.data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return {
    data,
    loading,
    error,
    addDrive,
    updateDrive,
    saving,
  };
};

export default useVaccinationDrive;
