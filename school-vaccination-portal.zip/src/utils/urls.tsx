export const student_service_url = "http://localhost:8081";
export const vaccine_service_url = "http://localhost:8080";
