import { createTheme, MantineProvider } from "@mantine/core";
import "@mantine/core/styles.css";
import "@mantine/dates/styles.css";
import "@mantine/notifications/styles.css";
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter, Route, Routes } from "react-router";
import "./index.css";
import Dashboard from "./pages/Dashboard.tsx";
import Login from "./pages/Login.tsx";
import Reports from "./pages/Reports.tsx";
import StudentManagement from "./pages/StudentManagement.tsx";
import VaccinationDriveManagement from "./pages/VaccinationDriveManagement.tsx";
import { Notifications } from "@mantine/notifications";

const theme = createTheme({
  /** Put your mantine theme override here */
});

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <MantineProvider theme={theme}>
      <Notifications />
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/students" element={<StudentManagement />} />
          <Route
            path="/vaccination-drive"
            element={<VaccinationDriveManagement />}
          />
          <Route path="/reports" element={<Reports />} />
          <Route path="*" element={<>Not found</>} />
        </Routes>
      </BrowserRouter>
    </MantineProvider>
  </StrictMode>
);
